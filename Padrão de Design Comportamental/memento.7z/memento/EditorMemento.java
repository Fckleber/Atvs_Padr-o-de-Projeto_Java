package memento;

public class EditorMemento {
    // O estado é 'final' para garantir a imutabilidade após a criação.
    private final String conteudo;

    
     // Construtor que recebe o estado a ser salvo.
     
    public EditorMemento(String conteudo) {
        this.conteudo = conteudo;
    }

   
    public String getConteudo() {
        return conteudo;
    }
}