package memento;

import java.util.ArrayDeque;
import java.util.Deque;

public class Historico {
    // Pilha para a funcionalidade de "Desfazer" (Undo)
    private final Deque<EditorMemento> historicoUndo;
    // Pilha para a funcionalidade de "Refazer" (Redo)
    private final Deque<EditorMemento> historicoRedo;

    public Historico() {
        this.historicoUndo = new ArrayDeque<>();
        this.historicoRedo = new ArrayDeque<>();
    }

 
    public void salvar(EditorMemento memento) {
        historicoUndo.push(memento);
        historicoRedo.clear(); // Limpa o histórico de "refazer"
    }


    public EditorMemento desfazer() {
        if (historicoUndo.isEmpty()) {
            return null;
        }

        EditorMemento memento = historicoUndo.pop();
        historicoRedo.push(memento);

        // Retorna o estado que estava antes do que foi removido
        return historicoUndo.peek();
    }

    public EditorMemento refazer() {
        if (historicoRedo.isEmpty()) {
            return null;
        }

        EditorMemento memento = historicoRedo.pop();
        historicoUndo.push(memento);

        return memento;
    }
}