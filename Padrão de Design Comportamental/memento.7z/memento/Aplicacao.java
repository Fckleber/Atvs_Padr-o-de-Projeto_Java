package memento;


public class Aplicacao {

    public static void main(String[] args) {
        Editor editor = new Editor();
        Historico historico = new Historico();

        // Salva o estado inicial (vazio)
        historico.salvar(editor.salvar());

        // 1. Escreve "Olá"
        editor.escrever("Olá");
        System.out.println("Estado atual: " + editor.getConteudo());
        historico.salvar(editor.salvar());

        // 2. Adiciona " Mundo"
        editor.escrever(" Mundo");
        System.out.println("Estado atual: " + editor.getConteudo());
        historico.salvar(editor.salvar());

        // 3. Adiciona "!"
        editor.escrever("!");
        System.out.println("Estado atual: " + editor.getConteudo());
        historico.salvar(editor.salvar());

        System.out.println("\n--- Realizando operações de Desfazer/Refazer ---\n");


        // Desfaz a adição do "!"
        EditorMemento estadoAnterior1 = historico.desfazer();
        if (estadoAnterior1 != null) {
            editor.restaurar(estadoAnterior1);
        }
        System.out.println("Após 1º desfazer: " + editor.getConteudo());

    
        EditorMemento estadoAnterior2 = historico.desfazer();
        if (estadoAnterior2 != null) {
            editor.restaurar(estadoAnterior2);
        }
        System.out.println("Após 2º desfazer: " + editor.getConteudo());

 
        // Refaz a adição do " Mundo"
        EditorMemento estadoRefeito1 = historico.refazer();
        if (estadoRefeito1 != null) {
            editor.restaurar(estadoRefeito1);
        }
        System.out.println("Após 1º refazer: " + editor.getConteudo());

  
        // Desfaz novamente para "Olá"
        EditorMemento estadoAnterior3 = historico.desfazer();
        if (estadoAnterior3 != null) {
            editor.restaurar(estadoAnterior3);
        }
        System.out.println("Após 3º desfazer: " + editor.getConteudo());
        
  
        System.out.println("\n--- Escrevendo algo novo para invalidar o 'refazer' ---\n");
        editor.escrever(" Java");
        System.out.println("Estado atual: " + editor.getConteudo());
        historico.salvar(editor.salvar());

        // Tenta refazer. Não deve acontecer nada, pois o histórico de refazer foi limpo.
        EditorMemento estadoRefeito2 = historico.refazer();
        if (estadoRefeito2 == null) {
            System.out.println("Não há nada para refazer.");
        }
        System.out.println("Estado final: " + editor.getConteudo());
    }
}