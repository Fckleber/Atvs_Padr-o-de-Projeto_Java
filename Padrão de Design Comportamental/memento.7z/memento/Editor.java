package memento;


public class Editor {
    private StringBuilder conteudo; // Usamos StringBuilder para facilitar a manipulação do texto.

    public Editor() {
        this.conteudo = new StringBuilder();
    }

  
    public void escrever(String texto) {
        this.conteudo.append(texto);
    }

   
    public String getConteudo() {
        return conteudo.toString();
    }

    
    public EditorMemento salvar() {
        return new EditorMemento(this.conteudo.toString());
    }

   
    public void restaurar(EditorMemento memento) {
        this.conteudo = new StringBuilder(memento.getConteudo());
    }
}